CREATE DEFINER = `mysql.sys`@localhost VIEW memory_global_total AS
SELECT format_bytes(sum(
        `performance_schema`.`memory_summary_global_by_event_name`.`current_number_of_bytes_used`)) AS `total_allocated`
FROM `performance_schema`.`memory_summary_global_by_event_name`;

