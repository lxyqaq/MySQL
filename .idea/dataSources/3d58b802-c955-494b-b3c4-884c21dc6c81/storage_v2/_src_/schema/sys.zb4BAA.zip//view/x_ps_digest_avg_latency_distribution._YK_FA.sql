CREATE DEFINER = `mysql.sys`@localhost VIEW x$ps_digest_avg_latency_distribution AS
SELECT count(0)                                                                                          AS `cnt`,
       round((`performance_schema`.`events_statements_summary_by_digest`.`avg_timer_wait` / 1000000), 0) AS `avg_us`
FROM `performance_schema`.`events_statements_summary_by_digest`
GROUP BY `avg_us`;

