CREATE DEFINER = `mysql.sys`@localhost VIEW schema_object_overview AS
SELECT `routines`.`routine_schema` AS `db`, `routines`.`routine_type` AS `object_type`, count(0) AS `count`
FROM `information_schema`.`routines`
GROUP BY `routines`.`routine_schema`, `routines`.`routine_type`
UNION
SELECT `tables`.`table_schema` AS `table_schema`, `tables`.`table_type` AS `table_type`, count(0) AS `count(*)`
FROM `information_schema`.`tables`
GROUP BY `tables`.`table_schema`, `tables`.`table_type`
UNION
SELECT `statistics`.`table_schema`                       AS `table_schema`,
       concat('INDEX (', `statistics`.`index_type`, ')') AS `concat('index (', index_type, ')')`,
       count(0)                                          AS `count(*)`
FROM `information_schema`.`statistics`
GROUP BY `statistics`.`table_schema`, `statistics`.`index_type`
UNION
SELECT `triggers`.`trigger_schema` AS `trigger_schema`, 'TRIGGER' AS `trigger`, count(0) AS `count(*)`
FROM `information_schema`.`triggers`
GROUP BY `triggers`.`trigger_schema`
UNION
SELECT `events`.`event_schema` AS `event_schema`, 'EVENT' AS `event`, count(0) AS `count(*)`
FROM `information_schema`.`events`
GROUP BY `events`.`event_schema`
ORDER BY `db`, `object_type`;

