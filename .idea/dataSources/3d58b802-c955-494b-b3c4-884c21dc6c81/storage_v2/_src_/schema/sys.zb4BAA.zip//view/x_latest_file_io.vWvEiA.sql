CREATE DEFINER = `mysql.sys`@localhost VIEW x$latest_file_io AS
SELECT if((`information_schema`.`processlist`.`id` IS NULL),
          concat(substring_index(`performance_schema`.`threads`.`name`, '/', -(1)), ':',
                 `performance_schema`.`events_waits_history_long`.`thread_id`), convert(
                  concat(`information_schema`.`processlist`.`user`, '@', `information_schema`.`processlist`.`host`, ':',
                         `information_schema`.`processlist`.`id`) USING utf8mb4)) AS `thread`,
       `performance_schema`.`events_waits_history_long`.`object_name`             AS `file`,
       `performance_schema`.`events_waits_history_long`.`timer_wait`              AS `latency`,
       `performance_schema`.`events_waits_history_long`.`operation`               AS `operation`,
       `performance_schema`.`events_waits_history_long`.`number_of_bytes`         AS `requested`
FROM ((`performance_schema`.`events_waits_history_long` JOIN `performance_schema`.`threads` ON ((
        `performance_schema`.`events_waits_history_long`.`thread_id` = `performance_schema`.`threads`.`thread_id`)))
         LEFT JOIN `information_schema`.`processlist`
                   ON ((`performance_schema`.`threads`.`processlist_id` = `information_schema`.`processlist`.`id`)))
WHERE ((`performance_schema`.`events_waits_history_long`.`object_name` IS NOT NULL) AND
       (`performance_schema`.`events_waits_history_long`.`event_name` LIKE 'wait/io/file/%'))
ORDER BY `performance_schema`.`events_waits_history_long`.`timer_start`;

