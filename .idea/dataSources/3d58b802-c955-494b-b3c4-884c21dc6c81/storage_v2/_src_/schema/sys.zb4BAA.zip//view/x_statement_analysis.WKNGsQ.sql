CREATE DEFINER = `mysql.sys`@localhost VIEW x$statement_analysis AS
SELECT `performance_schema`.`events_statements_summary_by_digest`.`digest_text`                                  AS `query`,
       `performance_schema`.`events_statements_summary_by_digest`.`schema_name`                                  AS `db`,
       if(((`performance_schema`.`events_statements_summary_by_digest`.`sum_no_good_index_used` > 0) OR
           (`performance_schema`.`events_statements_summary_by_digest`.`sum_no_index_used` > 0)), '*',
          '')                                                                                                    AS `full_scan`,
       `performance_schema`.`events_statements_summary_by_digest`.`count_star`                                   AS `exec_count`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_errors`                                   AS `err_count`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_warnings`                                 AS `warn_count`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_timer_wait`                               AS `total_latency`,
       `performance_schema`.`events_statements_summary_by_digest`.`max_timer_wait`                               AS `max_latency`,
       `performance_schema`.`events_statements_summary_by_digest`.`avg_timer_wait`                               AS `avg_latency`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_lock_time`                                AS `lock_latency`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_rows_sent`                                AS `rows_sent`,
       round(ifnull((`performance_schema`.`events_statements_summary_by_digest`.`sum_rows_sent` /
                     nullif(`performance_schema`.`events_statements_summary_by_digest`.`count_star`, 0)), 0),
             0)                                                                                                  AS `rows_sent_avg`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_rows_examined`                            AS `rows_examined`,
       round(ifnull((`performance_schema`.`events_statements_summary_by_digest`.`sum_rows_examined` /
                     nullif(`performance_schema`.`events_statements_summary_by_digest`.`count_star`, 0)), 0),
             0)                                                                                                  AS `rows_examined_avg`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_rows_affected`                            AS `rows_affected`,
       round(ifnull((`performance_schema`.`events_statements_summary_by_digest`.`sum_rows_affected` /
                     nullif(`performance_schema`.`events_statements_summary_by_digest`.`count_star`, 0)), 0),
             0)                                                                                                  AS `rows_affected_avg`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_created_tmp_tables`                       AS `tmp_tables`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_created_tmp_disk_tables`                  AS `tmp_disk_tables`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_sort_rows`                                AS `rows_sorted`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_sort_merge_passes`                        AS `sort_merge_passes`,
       `performance_schema`.`events_statements_summary_by_digest`.`digest`                                       AS `digest`,
       `performance_schema`.`events_statements_summary_by_digest`.`first_seen`                                   AS `first_seen`,
       `performance_schema`.`events_statements_summary_by_digest`.`last_seen`                                    AS `last_seen`
FROM `performance_schema`.`events_statements_summary_by_digest`
ORDER BY `performance_schema`.`events_statements_summary_by_digest`.`sum_timer_wait` DESC;

