CREATE DEFINER = `mysql.sys`@localhost VIEW x$memory_by_host_by_current_bytes AS
SELECT if((`performance_schema`.`memory_summary_by_host_by_event_name`.`host` IS NULL), 'background',
          `performance_schema`.`memory_summary_by_host_by_event_name`.`host`) AS                              `host`,
       sum(
               `performance_schema`.`memory_summary_by_host_by_event_name`.`current_count_used`) AS           `current_count_used`,
       sum(
               `performance_schema`.`memory_summary_by_host_by_event_name`.`current_number_of_bytes_used`) AS `current_allocated`,
       ifnull((sum(`performance_schema`.`memory_summary_by_host_by_event_name`.`current_number_of_bytes_used`) /
               nullif(sum(`performance_schema`.`memory_summary_by_host_by_event_name`.`current_count_used`), 0)),
              0) AS                                                                                           `current_avg_alloc`,
       max(
               `performance_schema`.`memory_summary_by_host_by_event_name`.`current_number_of_bytes_used`) AS `current_max_alloc`,
       sum(`performance_schema`.`memory_summary_by_host_by_event_name`.`sum_number_of_bytes_alloc`) AS        `total_allocated`
FROM `performance_schema`.`memory_summary_by_host_by_event_name`
GROUP BY if((`performance_schema`.`memory_summary_by_host_by_event_name`.`host` IS NULL), 'background',
            `performance_schema`.`memory_summary_by_host_by_event_name`.`host`)
ORDER BY sum(`performance_schema`.`memory_summary_by_host_by_event_name`.`current_number_of_bytes_used`) DESC;

