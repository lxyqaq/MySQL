CREATE DEFINER = `mysql.sys`@localhost VIEW user_summary_by_statement_type AS
SELECT if((`performance_schema`.`events_statements_summary_by_user_by_event_name`.`user` IS NULL), 'background',
          `performance_schema`.`events_statements_summary_by_user_by_event_name`.`user`)                         AS `user`,
       substring_index(`performance_schema`.`events_statements_summary_by_user_by_event_name`.`event_name`, '/',
                       -(1))                                                                                     AS `statement`,
       `performance_schema`.`events_statements_summary_by_user_by_event_name`.`count_star`                       AS `total`,
       format_pico_time(
               `performance_schema`.`events_statements_summary_by_user_by_event_name`.`sum_timer_wait`)          AS `total_latency`,
       format_pico_time(
               `performance_schema`.`events_statements_summary_by_user_by_event_name`.`max_timer_wait`)          AS `max_latency`,
       format_pico_time(
               `performance_schema`.`events_statements_summary_by_user_by_event_name`.`sum_lock_time`)           AS `lock_latency`,
       `performance_schema`.`events_statements_summary_by_user_by_event_name`.`sum_rows_sent`                    AS `rows_sent`,
       `performance_schema`.`events_statements_summary_by_user_by_event_name`.`sum_rows_examined`                AS `rows_examined`,
       `performance_schema`.`events_statements_summary_by_user_by_event_name`.`sum_rows_affected`                AS `rows_affected`,
       (`performance_schema`.`events_statements_summary_by_user_by_event_name`.`sum_no_index_used` +
        `performance_schema`.`events_statements_summary_by_user_by_event_name`.`sum_no_good_index_used`)         AS `full_scans`
FROM `performance_schema`.`events_statements_summary_by_user_by_event_name`
WHERE (`performance_schema`.`events_statements_summary_by_user_by_event_name`.`sum_timer_wait` <> 0)
ORDER BY if((`performance_schema`.`events_statements_summary_by_user_by_event_name`.`user` IS NULL), 'background',
            `performance_schema`.`events_statements_summary_by_user_by_event_name`.`user`),
         `performance_schema`.`events_statements_summary_by_user_by_event_name`.`sum_timer_wait` DESC;

