CREATE DEFINER = `mysql.sys`@localhost VIEW host_summary AS
SELECT if((`performance_schema`.`accounts`.`host` IS NULL), 'background',
          `performance_schema`.`accounts`.`host`)                                                  AS `host`,
       sum(`stmt`.`total`)                                                                         AS `statements`,
       format_pico_time(sum(`stmt`.`total_latency`))                                               AS `statement_latency`,
       format_pico_time(ifnull((sum(`stmt`.`total_latency`) / nullif(sum(`stmt`.`total`), 0)),
                               0))                                                                 AS `statement_avg_latency`,
       sum(`stmt`.`full_scans`)                                                                    AS `table_scans`,
       sum(`io`.`ios`)                                                                             AS `file_ios`,
       format_pico_time(sum(`io`.`io_latency`))                                                    AS `file_io_latency`,
       sum(`performance_schema`.`accounts`.`current_connections`)                                  AS `current_connections`,
       sum(`performance_schema`.`accounts`.`total_connections`)                                    AS `total_connections`,
       count(DISTINCT `performance_schema`.`accounts`.`user`)                                      AS `unique_users`,
       format_bytes(sum(`mem`.`current_allocated`))                                                AS `current_memory`,
       format_bytes(sum(`mem`.`total_allocated`))                                                  AS `total_memory_allocated`
FROM (((`performance_schema`.`accounts` JOIN `sys`.`x$host_summary_by_statement_latency` `stmt` ON ((`performance_schema`.`accounts`.`host` = `stmt`.`host`))) JOIN `sys`.`x$host_summary_by_file_io` `io` ON ((`performance_schema`.`accounts`.`host` = `io`.`host`)))
         JOIN `sys`.`x$memory_by_host_by_current_bytes` `mem`
              ON ((`performance_schema`.`accounts`.`host` = `mem`.`host`)))
GROUP BY if((`performance_schema`.`accounts`.`host` IS NULL), 'background', `performance_schema`.`accounts`.`host`);

