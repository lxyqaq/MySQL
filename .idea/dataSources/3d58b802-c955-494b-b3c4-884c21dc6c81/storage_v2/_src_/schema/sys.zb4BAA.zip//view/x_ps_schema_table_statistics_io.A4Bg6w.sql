CREATE DEFINER = `mysql.sys`@localhost VIEW x$ps_schema_table_statistics_io AS
SELECT `extract_schema_from_file_name`(`performance_schema`.`file_summary_by_instance`.`file_name`) AS `table_schema`,
       `extract_table_from_file_name`(`performance_schema`.`file_summary_by_instance`.`file_name`)  AS `table_name`,
       sum(`performance_schema`.`file_summary_by_instance`.`count_read`)                            AS `count_read`,
       sum(
               `performance_schema`.`file_summary_by_instance`.`sum_number_of_bytes_read`)          AS `sum_number_of_bytes_read`,
       sum(`performance_schema`.`file_summary_by_instance`.`sum_timer_read`)                        AS `sum_timer_read`,
       sum(`performance_schema`.`file_summary_by_instance`.`count_write`)                           AS `count_write`,
       sum(
               `performance_schema`.`file_summary_by_instance`.`sum_number_of_bytes_write`)         AS `sum_number_of_bytes_write`,
       sum(
               `performance_schema`.`file_summary_by_instance`.`sum_timer_write`)                   AS `sum_timer_write`,
       sum(`performance_schema`.`file_summary_by_instance`.`count_misc`)                            AS `count_misc`,
       sum(`performance_schema`.`file_summary_by_instance`.`sum_timer_misc`)                        AS `sum_timer_misc`
FROM `performance_schema`.`file_summary_by_instance`
GROUP BY `table_schema`, `table_name`;

