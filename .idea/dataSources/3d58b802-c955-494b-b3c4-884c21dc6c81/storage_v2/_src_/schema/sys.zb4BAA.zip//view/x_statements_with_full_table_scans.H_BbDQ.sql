CREATE DEFINER = `mysql.sys`@localhost VIEW x$statements_with_full_table_scans AS
SELECT `performance_schema`.`events_statements_summary_by_digest`.`digest_text`            AS `query`,
       `performance_schema`.`events_statements_summary_by_digest`.`schema_name`            AS `db`,
       `performance_schema`.`events_statements_summary_by_digest`.`count_star`             AS `exec_count`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_timer_wait`         AS `total_latency`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_no_index_used`      AS `no_index_used_count`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_no_good_index_used` AS `no_good_index_used_count`,
       round((ifnull((`performance_schema`.`events_statements_summary_by_digest`.`sum_no_index_used` /
                      nullif(`performance_schema`.`events_statements_summary_by_digest`.`count_star`, 0)), 0) * 100),
             0)                                                                            AS `no_index_used_pct`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_rows_sent`          AS `rows_sent`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_rows_examined`      AS `rows_examined`,
       round((`performance_schema`.`events_statements_summary_by_digest`.`sum_rows_sent` /
              `performance_schema`.`events_statements_summary_by_digest`.`count_star`), 0) AS `rows_sent_avg`,
       round((`performance_schema`.`events_statements_summary_by_digest`.`sum_rows_examined` /
              `performance_schema`.`events_statements_summary_by_digest`.`count_star`), 0) AS `rows_examined_avg`,
       `performance_schema`.`events_statements_summary_by_digest`.`first_seen`             AS `first_seen`,
       `performance_schema`.`events_statements_summary_by_digest`.`last_seen`              AS `last_seen`,
       `performance_schema`.`events_statements_summary_by_digest`.`digest`                 AS `digest`
FROM `performance_schema`.`events_statements_summary_by_digest`
WHERE (((`performance_schema`.`events_statements_summary_by_digest`.`sum_no_index_used` > 0) OR
        (`performance_schema`.`events_statements_summary_by_digest`.`sum_no_good_index_used` > 0)) AND
       (NOT ((`performance_schema`.`events_statements_summary_by_digest`.`digest_text` LIKE 'SHOW%'))))
ORDER BY round((ifnull((`performance_schema`.`events_statements_summary_by_digest`.`sum_no_index_used` /
                        nullif(`performance_schema`.`events_statements_summary_by_digest`.`count_star`, 0)), 0) * 100),
               0) DESC, `performance_schema`.`events_statements_summary_by_digest`.`sum_timer_wait` DESC;

