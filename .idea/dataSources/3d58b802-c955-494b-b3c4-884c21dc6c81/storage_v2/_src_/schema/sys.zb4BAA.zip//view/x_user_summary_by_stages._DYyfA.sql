CREATE DEFINER = `mysql.sys`@localhost VIEW x$user_summary_by_stages AS
SELECT if((`performance_schema`.`events_stages_summary_by_user_by_event_name`.`user` IS NULL), 'background',
          `performance_schema`.`events_stages_summary_by_user_by_event_name`.`user`)       AS `user`,
       `performance_schema`.`events_stages_summary_by_user_by_event_name`.`event_name`     AS `event_name`,
       `performance_schema`.`events_stages_summary_by_user_by_event_name`.`count_star`     AS `total`,
       `performance_schema`.`events_stages_summary_by_user_by_event_name`.`sum_timer_wait` AS `total_latency`,
       `performance_schema`.`events_stages_summary_by_user_by_event_name`.`avg_timer_wait` AS `avg_latency`
FROM `performance_schema`.`events_stages_summary_by_user_by_event_name`
WHERE (`performance_schema`.`events_stages_summary_by_user_by_event_name`.`sum_timer_wait` <> 0)
ORDER BY if((`performance_schema`.`events_stages_summary_by_user_by_event_name`.`user` IS NULL), 'background',
            `performance_schema`.`events_stages_summary_by_user_by_event_name`.`user`),
         `performance_schema`.`events_stages_summary_by_user_by_event_name`.`sum_timer_wait` DESC;

