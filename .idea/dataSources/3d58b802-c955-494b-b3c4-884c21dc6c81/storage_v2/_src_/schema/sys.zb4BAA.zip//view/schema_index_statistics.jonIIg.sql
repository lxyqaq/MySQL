CREATE DEFINER = `mysql.sys`@localhost VIEW schema_index_statistics AS
SELECT `performance_schema`.`table_io_waits_summary_by_index_usage`.`object_schema`                      AS `table_schema`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`object_name`                        AS `table_name`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`index_name`                         AS `index_name`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`count_fetch`                        AS `rows_selected`,
       format_pico_time(
               `performance_schema`.`table_io_waits_summary_by_index_usage`.`sum_timer_fetch`)           AS `select_latency`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`count_insert`                       AS `rows_inserted`,
       format_pico_time(
               `performance_schema`.`table_io_waits_summary_by_index_usage`.`sum_timer_insert`)          AS `insert_latency`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`count_update`                       AS `rows_updated`,
       format_pico_time(
               `performance_schema`.`table_io_waits_summary_by_index_usage`.`sum_timer_update`)          AS `update_latency`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`count_delete`                       AS `rows_deleted`,
       format_pico_time(
               `performance_schema`.`table_io_waits_summary_by_index_usage`.`sum_timer_delete`)          AS `delete_latency`
FROM `performance_schema`.`table_io_waits_summary_by_index_usage`
WHERE (`performance_schema`.`table_io_waits_summary_by_index_usage`.`index_name` IS NOT NULL)
ORDER BY `performance_schema`.`table_io_waits_summary_by_index_usage`.`sum_timer_wait` DESC;

