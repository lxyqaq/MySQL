CREATE DEFINER = `mysql.sys`@localhost VIEW schema_auto_increment_columns AS
SELECT `columns`.`table_schema`                                                                    AS `table_schema`,
       `columns`.`table_name`                                                                      AS `table_name`,
       `columns`.`column_name`                                                                     AS `column_name`,
       `columns`.`data_type`                                                                       AS `data_type`,
       `columns`.`column_type`                                                                     AS `column_type`,
       (locate('unsigned', `columns`.`column_type`) = 0)                                           AS `is_signed`,
       (locate('unsigned', `columns`.`column_type`) > 0)                                           AS `is_unsigned`,
       ((CASE `columns`.`data_type`
             WHEN 'tinyint' THEN 255
             WHEN 'smallint' THEN 65535
             WHEN 'mediumint' THEN 16777215
             WHEN 'int' THEN 4294967295
             WHEN 'bigint' THEN 18446744073709551615 END) >>
        if((locate('unsigned', `columns`.`column_type`) > 0), 0, 1))                               AS `max_value`,
       `tables`.`auto_increment`                                                                   AS `auto_increment`,
       (`tables`.`auto_increment` / ((CASE `columns`.`data_type`
                                          WHEN 'tinyint' THEN 255
                                          WHEN 'smallint' THEN 65535
                                          WHEN 'mediumint' THEN 16777215
                                          WHEN 'int' THEN 4294967295
                                          WHEN 'bigint' THEN 18446744073709551615 END) >>
                                     if((locate('unsigned', `columns`.`column_type`) > 0), 0, 1))) AS `auto_increment_ratio`
FROM (`information_schema`.`columns`
         JOIN `information_schema`.`tables` ON (((`columns`.`table_schema` = `tables`.`table_schema`) AND
                                                 (`columns`.`table_name` = `tables`.`table_name`))))
WHERE ((`columns`.`table_schema` NOT IN ('mysql', 'sys', 'INFORMATION_SCHEMA', 'performance_schema')) AND
       (`tables`.`table_type` = 'BASE TABLE') AND (`columns`.`extra` = 'auto_increment'))
ORDER BY (`tables`.`auto_increment` / ((CASE `columns`.`data_type`
                                            WHEN 'tinyint' THEN 255
                                            WHEN 'smallint' THEN 65535
                                            WHEN 'mediumint' THEN 16777215
                                            WHEN 'int' THEN 4294967295
                                            WHEN 'bigint' THEN 18446744073709551615 END) >>
                                       if((locate('unsigned', `columns`.`column_type`) > 0), 0, 1))) DESC,
         ((CASE `columns`.`data_type`
               WHEN 'tinyint' THEN 255
               WHEN 'smallint' THEN 65535
               WHEN 'mediumint' THEN 16777215
               WHEN 'int' THEN 4294967295
               WHEN 'bigint' THEN 18446744073709551615 END) >>
          if((locate('unsigned', `columns`.`column_type`) > 0), 0, 1));

