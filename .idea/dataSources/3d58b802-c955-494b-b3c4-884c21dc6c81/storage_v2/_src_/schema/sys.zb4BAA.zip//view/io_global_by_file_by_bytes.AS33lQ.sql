CREATE DEFINER = `mysql.sys`@localhost VIEW io_global_by_file_by_bytes AS
SELECT `sys`.`format_path`(`performance_schema`.`file_summary_by_instance`.`file_name`)                              AS `file`,
       `performance_schema`.`file_summary_by_instance`.`count_read`                                                  AS `count_read`,
       format_bytes(
               `performance_schema`.`file_summary_by_instance`.`sum_number_of_bytes_read`)                           AS `total_read`,
       format_bytes(ifnull((`performance_schema`.`file_summary_by_instance`.`sum_number_of_bytes_read` /
                            nullif(`performance_schema`.`file_summary_by_instance`.`count_read`, 0)),
                           0))                                                                                       AS `avg_read`,
       `performance_schema`.`file_summary_by_instance`.`count_write`                                                 AS `count_write`,
       format_bytes(
               `performance_schema`.`file_summary_by_instance`.`sum_number_of_bytes_write`)                          AS `total_written`,
       format_bytes(ifnull((`performance_schema`.`file_summary_by_instance`.`sum_number_of_bytes_write` /
                            nullif(`performance_schema`.`file_summary_by_instance`.`count_write`, 0)),
                           0.00))                                                                                    AS `avg_write`,
       format_bytes((`performance_schema`.`file_summary_by_instance`.`sum_number_of_bytes_read` +
                     `performance_schema`.`file_summary_by_instance`.`sum_number_of_bytes_write`))                   AS `total`,
       ifnull(round((100 - ((`performance_schema`.`file_summary_by_instance`.`sum_number_of_bytes_read` / nullif(
               (`performance_schema`.`file_summary_by_instance`.`sum_number_of_bytes_read` +
                `performance_schema`.`file_summary_by_instance`.`sum_number_of_bytes_write`), 0)) * 100)), 2),
              0.00)                                                                                                  AS `write_pct`
FROM `performance_schema`.`file_summary_by_instance`
ORDER BY (`performance_schema`.`file_summary_by_instance`.`sum_number_of_bytes_read` +
          `performance_schema`.`file_summary_by_instance`.`sum_number_of_bytes_write`) DESC;

