CREATE DEFINER = `mysql.sys`@localhost VIEW memory_by_thread_by_current_bytes AS
SELECT `mt`.`thread_id`                                                                                           AS `thread_id`,
       if((`t`.`name` = 'thread/sql/one_connection'),
          concat(`t`.`processlist_user`, '@', convert(`t`.`processlist_host` USING utf8mb4)),
          replace(`t`.`name`, 'thread/', ''))                                                                     AS `user`,
       sum(`mt`.`current_count_used`)                                                                             AS `current_count_used`,
       format_bytes(sum(`mt`.`current_number_of_bytes_used`))                                                     AS `current_allocated`,
       format_bytes(ifnull((sum(`mt`.`current_number_of_bytes_used`) / nullif(sum(`mt`.`current_count_used`), 0)),
                           0))                                                                                    AS `current_avg_alloc`,
       format_bytes(max(`mt`.`current_number_of_bytes_used`))                                                     AS `current_max_alloc`,
       format_bytes(sum(`mt`.`sum_number_of_bytes_alloc`))                                                        AS `total_allocated`
FROM (`performance_schema`.`memory_summary_by_thread_by_event_name` `mt`
         JOIN `performance_schema`.`threads` `t` ON ((`mt`.`thread_id` = `t`.`thread_id`)))
GROUP BY `mt`.`thread_id`,
         if((`t`.`name` = 'thread/sql/one_connection'),
            concat(`t`.`processlist_user`, '@', convert(`t`.`processlist_host` USING utf8mb4)),
            replace(`t`.`name`, 'thread/', ''))
ORDER BY sum(`mt`.`current_number_of_bytes_used`) DESC;

