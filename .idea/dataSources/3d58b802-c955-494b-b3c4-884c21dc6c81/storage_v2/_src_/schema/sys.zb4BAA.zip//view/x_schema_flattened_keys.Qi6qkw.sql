CREATE DEFINER = `mysql.sys`@localhost VIEW x$schema_flattened_keys AS
SELECT `statistics`.`table_schema`                                                                     AS `table_schema`,
       `statistics`.`table_name`                                                                       AS `table_name`,
       `statistics`.`index_name`                                                                       AS `index_name`,
       max(`statistics`.`non_unique`)                                                                  AS `non_unique`,
       max(if((`statistics`.`sub_part` IS NULL), 0, 1))                                                AS `subpart_exists`,
       group_concat(`statistics`.`column_name` ORDER BY `statistics`.`seq_in_index` ASC SEPARATOR
                    ',')                                                                               AS `index_columns`
FROM `information_schema`.`statistics`
WHERE ((`statistics`.`index_type` = 'BTREE') AND
       (`statistics`.`table_schema` NOT IN ('mysql', 'sys', 'INFORMATION_SCHEMA', 'PERFORMANCE_SCHEMA')))
GROUP BY `statistics`.`table_schema`, `statistics`.`table_name`, `statistics`.`index_name`;

