CREATE DEFINER = `mysql.sys`@localhost VIEW memory_global_by_current_bytes AS
SELECT `performance_schema`.`memory_summary_global_by_event_name`.`event_name`                                 AS `event_name`,
       `performance_schema`.`memory_summary_global_by_event_name`.`current_count_used`                         AS `current_count`,
       format_bytes(
               `performance_schema`.`memory_summary_global_by_event_name`.`current_number_of_bytes_used`)      AS `current_alloc`,
       format_bytes(ifnull((`performance_schema`.`memory_summary_global_by_event_name`.`current_number_of_bytes_used` /
                            nullif(`performance_schema`.`memory_summary_global_by_event_name`.`current_count_used`, 0)),
                           0))                                                                                 AS `current_avg_alloc`,
       `performance_schema`.`memory_summary_global_by_event_name`.`high_count_used`                            AS `high_count`,
       format_bytes(
               `performance_schema`.`memory_summary_global_by_event_name`.`high_number_of_bytes_used`)         AS `high_alloc`,
       format_bytes(ifnull((`performance_schema`.`memory_summary_global_by_event_name`.`high_number_of_bytes_used` /
                            nullif(`performance_schema`.`memory_summary_global_by_event_name`.`high_count_used`, 0)),
                           0))                                                                                 AS `high_avg_alloc`
FROM `performance_schema`.`memory_summary_global_by_event_name`
WHERE (`performance_schema`.`memory_summary_global_by_event_name`.`current_number_of_bytes_used` > 0)
ORDER BY `performance_schema`.`memory_summary_global_by_event_name`.`current_number_of_bytes_used` DESC;

