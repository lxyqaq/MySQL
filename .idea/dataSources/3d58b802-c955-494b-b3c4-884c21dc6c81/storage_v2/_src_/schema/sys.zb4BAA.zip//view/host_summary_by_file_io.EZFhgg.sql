CREATE DEFINER = `mysql.sys`@localhost VIEW host_summary_by_file_io AS
SELECT if((`performance_schema`.`events_waits_summary_by_host_by_event_name`.`host` IS NULL), 'background',
          `performance_schema`.`events_waits_summary_by_host_by_event_name`.`host`)                              AS `host`,
       sum(
               `performance_schema`.`events_waits_summary_by_host_by_event_name`.`count_star`)                   AS `ios`,
       format_pico_time(sum(
               `performance_schema`.`events_waits_summary_by_host_by_event_name`.`sum_timer_wait`))              AS `io_latency`
FROM `performance_schema`.`events_waits_summary_by_host_by_event_name`
WHERE (`performance_schema`.`events_waits_summary_by_host_by_event_name`.`event_name` LIKE 'wait/io/file/%')
GROUP BY if((`performance_schema`.`events_waits_summary_by_host_by_event_name`.`host` IS NULL), 'background',
            `performance_schema`.`events_waits_summary_by_host_by_event_name`.`host`)
ORDER BY sum(`performance_schema`.`events_waits_summary_by_host_by_event_name`.`sum_timer_wait`) DESC;

