CREATE DEFINER = `mysql.sys`@localhost VIEW io_global_by_wait_by_latency AS
SELECT substring_index(`performance_schema`.`file_summary_by_event_name`.`event_name`, '/', -(2))            AS `event_name`,
       `performance_schema`.`file_summary_by_event_name`.`count_star`                                        AS `total`,
       format_pico_time(
               `performance_schema`.`file_summary_by_event_name`.`sum_timer_wait`)                           AS `total_latency`,
       format_pico_time(
               `performance_schema`.`file_summary_by_event_name`.`avg_timer_wait`)                           AS `avg_latency`,
       format_pico_time(
               `performance_schema`.`file_summary_by_event_name`.`max_timer_wait`)                           AS `max_latency`,
       format_pico_time(
               `performance_schema`.`file_summary_by_event_name`.`sum_timer_read`)                           AS `read_latency`,
       format_pico_time(
               `performance_schema`.`file_summary_by_event_name`.`sum_timer_write`)                          AS `write_latency`,
       format_pico_time(
               `performance_schema`.`file_summary_by_event_name`.`sum_timer_misc`)                           AS `misc_latency`,
       `performance_schema`.`file_summary_by_event_name`.`count_read`                                        AS `count_read`,
       format_bytes(
               `performance_schema`.`file_summary_by_event_name`.`sum_number_of_bytes_read`)                 AS `total_read`,
       format_bytes(ifnull((`performance_schema`.`file_summary_by_event_name`.`sum_number_of_bytes_read` /
                            nullif(`performance_schema`.`file_summary_by_event_name`.`count_read`, 0)),
                           0))                                                                               AS `avg_read`,
       `performance_schema`.`file_summary_by_event_name`.`count_write`                                       AS `count_write`,
       format_bytes(
               `performance_schema`.`file_summary_by_event_name`.`sum_number_of_bytes_write`)                AS `total_written`,
       format_bytes(ifnull((`performance_schema`.`file_summary_by_event_name`.`sum_number_of_bytes_write` /
                            nullif(`performance_schema`.`file_summary_by_event_name`.`count_write`, 0)),
                           0))                                                                               AS `avg_written`
FROM `performance_schema`.`file_summary_by_event_name`
WHERE ((`performance_schema`.`file_summary_by_event_name`.`event_name` LIKE 'wait/io/file/%') AND
       (`performance_schema`.`file_summary_by_event_name`.`count_star` > 0))
ORDER BY `performance_schema`.`file_summary_by_event_name`.`sum_timer_wait` DESC;

