CREATE DEFINER = `mysql.sys`@localhost VIEW io_by_thread_by_latency AS
SELECT if((`performance_schema`.`threads`.`processlist_id` IS NULL),
          substring_index(`performance_schema`.`threads`.`name`, '/', -(1)),
          concat(`performance_schema`.`threads`.`processlist_user`, '@',
                 convert(`performance_schema`.`threads`.`processlist_host` USING utf8mb4)))                        AS `user`,
       sum(
               `performance_schema`.`events_waits_summary_by_thread_by_event_name`.`count_star`)                   AS `total`,
       format_pico_time(sum(
               `performance_schema`.`events_waits_summary_by_thread_by_event_name`.`sum_timer_wait`))              AS `total_latency`,
       format_pico_time(min(
               `performance_schema`.`events_waits_summary_by_thread_by_event_name`.`min_timer_wait`))              AS `min_latency`,
       format_pico_time(avg(
               `performance_schema`.`events_waits_summary_by_thread_by_event_name`.`avg_timer_wait`))              AS `avg_latency`,
       format_pico_time(max(
               `performance_schema`.`events_waits_summary_by_thread_by_event_name`.`max_timer_wait`))              AS `max_latency`,
       `performance_schema`.`events_waits_summary_by_thread_by_event_name`.`thread_id`                             AS `thread_id`,
       `performance_schema`.`threads`.`processlist_id`                                                             AS `processlist_id`
FROM (`performance_schema`.`events_waits_summary_by_thread_by_event_name`
         LEFT JOIN `performance_schema`.`threads`
                   ON ((`performance_schema`.`events_waits_summary_by_thread_by_event_name`.`thread_id` =
                        `performance_schema`.`threads`.`thread_id`)))
WHERE ((`performance_schema`.`events_waits_summary_by_thread_by_event_name`.`event_name` LIKE 'wait/io/file/%') AND
       (`performance_schema`.`events_waits_summary_by_thread_by_event_name`.`sum_timer_wait` > 0))
GROUP BY `performance_schema`.`events_waits_summary_by_thread_by_event_name`.`thread_id`,
         `performance_schema`.`threads`.`processlist_id`, `user`
ORDER BY sum(`performance_schema`.`events_waits_summary_by_thread_by_event_name`.`sum_timer_wait`) DESC;

