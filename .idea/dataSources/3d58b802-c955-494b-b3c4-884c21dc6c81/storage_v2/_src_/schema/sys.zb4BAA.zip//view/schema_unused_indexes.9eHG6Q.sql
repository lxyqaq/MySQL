CREATE DEFINER = `mysql.sys`@localhost VIEW schema_unused_indexes AS
SELECT `t`.`object_schema` AS `object_schema`, `t`.`object_name` AS `object_name`, `t`.`index_name` AS `index_name`
FROM (`performance_schema`.`table_io_waits_summary_by_index_usage` `t`
         JOIN `information_schema`.`statistics` `s`
              ON (((convert(`t`.`object_schema` USING utf8) = `s`.`table_schema`) AND
                   (convert(`t`.`object_name` USING utf8) = `s`.`table_name`) AND
                   (convert(`t`.`index_name` USING utf8) = `s`.`index_name`))))
WHERE ((`t`.`index_name` IS NOT NULL) AND (`t`.`count_star` = 0) AND (`t`.`object_schema` <> 'mysql') AND
       (`t`.`index_name` <> 'PRIMARY') AND (`s`.`non_unique` = 1) AND (`s`.`seq_in_index` = 1))
ORDER BY `t`.`object_schema`, `t`.`object_name`;

