CREATE DEFINER = `mysql.sys`@localhost VIEW x$io_global_by_file_by_latency AS
SELECT `performance_schema`.`file_summary_by_instance`.`file_name`       AS `file`,
       `performance_schema`.`file_summary_by_instance`.`count_star`      AS `total`,
       `performance_schema`.`file_summary_by_instance`.`sum_timer_wait`  AS `total_latency`,
       `performance_schema`.`file_summary_by_instance`.`count_read`      AS `count_read`,
       `performance_schema`.`file_summary_by_instance`.`sum_timer_read`  AS `read_latency`,
       `performance_schema`.`file_summary_by_instance`.`count_write`     AS `count_write`,
       `performance_schema`.`file_summary_by_instance`.`sum_timer_write` AS `write_latency`,
       `performance_schema`.`file_summary_by_instance`.`count_misc`      AS `count_misc`,
       `performance_schema`.`file_summary_by_instance`.`sum_timer_misc`  AS `misc_latency`
FROM `performance_schema`.`file_summary_by_instance`
ORDER BY `performance_schema`.`file_summary_by_instance`.`sum_timer_wait` DESC;

