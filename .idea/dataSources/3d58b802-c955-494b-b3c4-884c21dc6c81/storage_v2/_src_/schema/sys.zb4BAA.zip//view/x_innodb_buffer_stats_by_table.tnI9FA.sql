CREATE DEFINER = `mysql.sys`@localhost VIEW x$innodb_buffer_stats_by_table AS
SELECT if((locate('.', `ibp`.`table_name`) = 0), 'InnoDB System',
          replace(substring_index(`ibp`.`table_name`, '.', 1), '`', ''))                                  AS `object_schema`,
       replace(substring_index(`ibp`.`table_name`, '.', -(1)), '`', '')                                   AS `object_name`,
       sum(
               if((`ibp`.`compressed_size` = 0), 16384, `ibp`.`compressed_size`))                         AS `allocated`,
       sum(`ibp`.`data_size`)                                                                             AS `data`,
       count(`ibp`.`page_number`)                                                                         AS `pages`,
       count(if((`ibp`.`is_hashed` = 'YES'), 1, NULL))                                                    AS `pages_hashed`,
       count(if((`ibp`.`is_old` = 'YES'), 1, NULL))                                                       AS `pages_old`,
       round(ifnull((sum(`ibp`.`number_records`) / nullif(count(DISTINCT `ibp`.`index_name`), 0)), 0),
             0)                                                                                           AS `rows_cached`
FROM `information_schema`.`innodb_buffer_page` `ibp`
WHERE (`ibp`.`table_name` IS NOT NULL)
GROUP BY `object_schema`, `object_name`
ORDER BY sum(if((`ibp`.`compressed_size` = 0), 16384, `ibp`.`compressed_size`)) DESC;

