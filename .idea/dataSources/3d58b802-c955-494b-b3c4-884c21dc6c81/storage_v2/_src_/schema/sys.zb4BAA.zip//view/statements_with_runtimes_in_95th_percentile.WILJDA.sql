CREATE DEFINER = `mysql.sys`@localhost VIEW statements_with_runtimes_in_95th_percentile AS
SELECT `sys`.`format_statement`(`stmts`.`digest_text`)                                            AS `query`,
       `stmts`.`schema_name`                                                                      AS `db`,
       if(((`stmts`.`sum_no_good_index_used` > 0) OR (`stmts`.`sum_no_index_used` > 0)), '*', '') AS `full_scan`,
       `stmts`.`count_star`                                                                       AS `exec_count`,
       `stmts`.`sum_errors`                                                                       AS `err_count`,
       `stmts`.`sum_warnings`                                                                     AS `warn_count`,
       format_pico_time(`stmts`.`sum_timer_wait`)                                                 AS `total_latency`,
       format_pico_time(`stmts`.`max_timer_wait`)                                                 AS `max_latency`,
       format_pico_time(`stmts`.`avg_timer_wait`)                                                 AS `avg_latency`,
       `stmts`.`sum_rows_sent`                                                                    AS `rows_sent`,
       round(ifnull((`stmts`.`sum_rows_sent` / nullif(`stmts`.`count_star`, 0)), 0), 0)           AS `rows_sent_avg`,
       `stmts`.`sum_rows_examined`                                                                AS `rows_examined`,
       round(ifnull((`stmts`.`sum_rows_examined` / nullif(`stmts`.`count_star`, 0)), 0),
             0)                                                                                   AS `rows_examined_avg`,
       `stmts`.`first_seen`                                                                       AS `first_seen`,
       `stmts`.`last_seen`                                                                        AS `last_seen`,
       `stmts`.`digest`                                                                           AS `digest`
FROM (`performance_schema`.`events_statements_summary_by_digest` `stmts`
         JOIN `sys`.`x$ps_digest_95th_percentile_by_avg_us` `top_percentile`
              ON ((round((`stmts`.`avg_timer_wait` / 1000000), 0) >= `top_percentile`.`avg_us`)))
ORDER BY `stmts`.`avg_timer_wait` DESC;

