CREATE DEFINER = `mysql.sys`@localhost VIEW x$statements_with_sorting AS
SELECT `performance_schema`.`events_statements_summary_by_digest`.`digest_text`                                  AS `query`,
       `performance_schema`.`events_statements_summary_by_digest`.`schema_name`                                  AS `db`,
       `performance_schema`.`events_statements_summary_by_digest`.`count_star`                                   AS `exec_count`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_timer_wait`                               AS `total_latency`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_sort_merge_passes`                        AS `sort_merge_passes`,
       round(ifnull((`performance_schema`.`events_statements_summary_by_digest`.`sum_sort_merge_passes` /
                     nullif(`performance_schema`.`events_statements_summary_by_digest`.`count_star`, 0)), 0),
             0)                                                                                                  AS `avg_sort_merges`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_sort_scan`                                AS `sorts_using_scans`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_sort_range`                               AS `sort_using_range`,
       `performance_schema`.`events_statements_summary_by_digest`.`sum_sort_rows`                                AS `rows_sorted`,
       round(ifnull((`performance_schema`.`events_statements_summary_by_digest`.`sum_sort_rows` /
                     nullif(`performance_schema`.`events_statements_summary_by_digest`.`count_star`, 0)), 0),
             0)                                                                                                  AS `avg_rows_sorted`,
       `performance_schema`.`events_statements_summary_by_digest`.`first_seen`                                   AS `first_seen`,
       `performance_schema`.`events_statements_summary_by_digest`.`last_seen`                                    AS `last_seen`,
       `performance_schema`.`events_statements_summary_by_digest`.`digest`                                       AS `digest`
FROM `performance_schema`.`events_statements_summary_by_digest`
WHERE (`performance_schema`.`events_statements_summary_by_digest`.`sum_sort_rows` > 0)
ORDER BY `performance_schema`.`events_statements_summary_by_digest`.`sum_timer_wait` DESC;

