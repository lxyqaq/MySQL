CREATE DEFINER = `mysql.sys`@localhost VIEW x$host_summary_by_statement_latency AS
SELECT if((`performance_schema`.`events_statements_summary_by_host_by_event_name`.`host` IS NULL), 'background',
          `performance_schema`.`events_statements_summary_by_host_by_event_name`.`host`) AS                         `host`,
       sum(
               `performance_schema`.`events_statements_summary_by_host_by_event_name`.`count_star`) AS              `total`,
       sum(
               `performance_schema`.`events_statements_summary_by_host_by_event_name`.`sum_timer_wait`) AS          `total_latency`,
       max(
               `performance_schema`.`events_statements_summary_by_host_by_event_name`.`max_timer_wait`) AS          `max_latency`,
       sum(
               `performance_schema`.`events_statements_summary_by_host_by_event_name`.`sum_lock_time`) AS           `lock_latency`,
       sum(
               `performance_schema`.`events_statements_summary_by_host_by_event_name`.`sum_rows_sent`) AS           `rows_sent`,
       sum(
               `performance_schema`.`events_statements_summary_by_host_by_event_name`.`sum_rows_examined`) AS       `rows_examined`,
       sum(
               `performance_schema`.`events_statements_summary_by_host_by_event_name`.`sum_rows_affected`) AS       `rows_affected`,
       (sum(`performance_schema`.`events_statements_summary_by_host_by_event_name`.`sum_no_index_used`) + sum(
               `performance_schema`.`events_statements_summary_by_host_by_event_name`.`sum_no_good_index_used`)) AS `full_scans`
FROM `performance_schema`.`events_statements_summary_by_host_by_event_name`
GROUP BY if((`performance_schema`.`events_statements_summary_by_host_by_event_name`.`host` IS NULL), 'background',
            `performance_schema`.`events_statements_summary_by_host_by_event_name`.`host`)
ORDER BY sum(`performance_schema`.`events_statements_summary_by_host_by_event_name`.`sum_timer_wait`) DESC;

