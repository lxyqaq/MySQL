CREATE DEFINER = `mysql.sys`@localhost VIEW waits_by_host_by_latency AS
SELECT if((`performance_schema`.`events_waits_summary_by_host_by_event_name`.`host` IS NULL), 'background',
          `performance_schema`.`events_waits_summary_by_host_by_event_name`.`host`)                         AS `host`,
       `performance_schema`.`events_waits_summary_by_host_by_event_name`.`event_name`                       AS `event`,
       `performance_schema`.`events_waits_summary_by_host_by_event_name`.`count_star`                       AS `total`,
       format_pico_time(
               `performance_schema`.`events_waits_summary_by_host_by_event_name`.`sum_timer_wait`)          AS `total_latency`,
       format_pico_time(
               `performance_schema`.`events_waits_summary_by_host_by_event_name`.`avg_timer_wait`)          AS `avg_latency`,
       format_pico_time(
               `performance_schema`.`events_waits_summary_by_host_by_event_name`.`max_timer_wait`)          AS `max_latency`
FROM `performance_schema`.`events_waits_summary_by_host_by_event_name`
WHERE ((`performance_schema`.`events_waits_summary_by_host_by_event_name`.`event_name` <> 'idle') AND
       (`performance_schema`.`events_waits_summary_by_host_by_event_name`.`sum_timer_wait` > 0))
ORDER BY if((`performance_schema`.`events_waits_summary_by_host_by_event_name`.`host` IS NULL), 'background',
            `performance_schema`.`events_waits_summary_by_host_by_event_name`.`host`),
         `performance_schema`.`events_waits_summary_by_host_by_event_name`.`sum_timer_wait` DESC;

