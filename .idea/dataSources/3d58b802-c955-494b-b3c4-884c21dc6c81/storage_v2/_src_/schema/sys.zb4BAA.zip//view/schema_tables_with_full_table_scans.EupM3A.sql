CREATE DEFINER = `mysql.sys`@localhost VIEW schema_tables_with_full_table_scans AS
SELECT `performance_schema`.`table_io_waits_summary_by_index_usage`.`object_schema`                    AS `object_schema`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`object_name`                      AS `object_name`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`count_read`                       AS `rows_full_scanned`,
       format_pico_time(`performance_schema`.`table_io_waits_summary_by_index_usage`.`sum_timer_wait`) AS `latency`
FROM `performance_schema`.`table_io_waits_summary_by_index_usage`
WHERE ((`performance_schema`.`table_io_waits_summary_by_index_usage`.`index_name` IS NULL) AND
       (`performance_schema`.`table_io_waits_summary_by_index_usage`.`count_read` > 0))
ORDER BY `performance_schema`.`table_io_waits_summary_by_index_usage`.`count_read` DESC;

