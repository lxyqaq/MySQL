CREATE DEFINER = `mysql.sys`@localhost VIEW session_ssl_status AS
SELECT `sslver`.`thread_id`        AS `thread_id`,
       `sslver`.`variable_value`   AS `ssl_version`,
       `sslcip`.`variable_value`   AS `ssl_cipher`,
       `sslreuse`.`variable_value` AS `ssl_sessions_reused`
FROM ((`performance_schema`.`status_by_thread` `sslver` LEFT JOIN `performance_schema`.`status_by_thread` `sslcip` ON ((
        (`sslcip`.`thread_id` = `sslver`.`thread_id`) AND (`sslcip`.`variable_name` = 'Ssl_cipher'))))
         LEFT JOIN `performance_schema`.`status_by_thread` `sslreuse`
                   ON (((`sslreuse`.`thread_id` = `sslver`.`thread_id`) AND
                        (`sslreuse`.`variable_name` = 'Ssl_sessions_reused'))))
WHERE (`sslver`.`variable_name` = 'Ssl_version');

